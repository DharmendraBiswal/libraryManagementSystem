package com.yash.lbm.interfaces;

import java.util.List;

public interface IBook {
	
	public void searchBook(int bookID);
	public void searchBookByCategory(String category);

}
