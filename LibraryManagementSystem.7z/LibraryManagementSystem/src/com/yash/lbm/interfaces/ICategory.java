package com.yash.lbm.interfaces;

public interface ICategory {
	
	public void getCatagory(String catagory);

}
