package com.yash.lbm.interfaces;

public interface ICategorize {
	
	public void getBookByCategory();

}
